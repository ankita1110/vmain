<!--Footer Bottom section start-->
<div class="ed_footer_wrapper ed_toppadder60 ed_bottompadder30">
    <div class="ed_footer_top">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12">
                    <div class="widget text-widget">
                        <p><a href="index-2.html"><img src="images/footer/F_Logo.png" alt="Footer Logo" /></a></p>
                        <p>Transportation is the center of the world! It is the glue of our daily lives. When it goes well, we don't see it. When it goes wrong, it negatively colors our day, makes us feel angry and impotent.</p>
                        <div class="ed_sociallink">
                            <ul>
                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12">
                    <div class="widget text-widget">
                        <h4 class="widget-title">services</h4>
                        <div class="ed_footer_menu">
                            <ul>
                                <li><a href="#">Logistic</a></li>
                                <li><a href="#">Warehousing</a></li>
                                <li><a href="#">Ground Transport</a></li>
                                <li><a href="#">Packaging & Storage</a></li>
                                <li><a href="#">Door-To-Door Delivery</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12">
                    <div class="widget text-widget">
                        <h4 class="widget-title">quick links</h4>
                        <div class="ed_footer_menu">
                            <ul>
                                <li><a href="index-2.html">home</a></li>
                                <li><a href="about.html">about</a></li>
                                <li><a href="gallery.html">gallery</a></li>
                                <li><a href="contact.html">contact us</a></li>
                                <li><a href="private_policy.html">private policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12">
                    <div class="widget text-widget">
                        <h4 class="widget-title">find us</h4>
                        <p><i class="fa fa-home" aria-hidden="true"></i> 141 N Prospect Ave, Bergenfield, NJ, 07621</p>
                        <p><i class="fa fa-envelope" aria-hidden="true"></i><a href="#">info@transportingservices.com</a> <a href="#">public@transportingservices.co.in</a></p>
                        <p><i class="fa fa-phone" aria-hidden="true"></i> 1800-2202-0909</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="ed_footer_bottom">
    <div class="container">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="ed_copy_right">
                        <p>&copy; Copyright 2018, All Rights Reserved, <a href="#">TRANSPORT</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Footer Bottom section end-->
</div>
<!--Page main section end-->
<!--main js file start-->
<script type="text/javascript" src="js/jquery-1.12.2.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/modernizr.js"></script>
<script type="text/javascript" src="js/owl.carousel.js"></script>
<script type="text/javascript" src="js/smooth-scroll.js"></script>
<script type="text/javascript" src="js/jquery.magnific-popup.js"></script>
<script type="text/javascript" src="js/plugins/revel/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.parallax.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="js/plugins/revel/revolution.extension.video.min.js"></script>
<script type="text/javascript" src="js/plugins/countto/jquery.countTo.js"></script>
<script type="text/javascript" src="js/plugins/countto/jquery.appear.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
<!--main js file end-->
</body>

<!-- Mirrored from kamleshyadav.com/html/transport/transport/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Mar 2018 13:33:44 GMT -->
</html>