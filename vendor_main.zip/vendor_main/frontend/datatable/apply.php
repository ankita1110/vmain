<!------------datatable---------------->   
        <link rel="stylesheet" href="../datatable/js/jquery-ui-1.11.4/jquery-ui.css"/>  
        <link rel="stylesheet" href="../datatable/css/jquery.dataTables.min.css"/>
        <link rel="stylesheet" href="../datatable/css/buttons.dataTables.min.css"/>
<!--
<script src="../datatable/js/jquery-2.2.0.min.js"></script> 
<script src="../datatable/js/jquery-ui-1.11.4/jquery-ui.js"></script>
-->
<link rel="stylesheet" href="../datatable/css/jquery.dataTables.min.css"/>
<script src="../datatable/js/jquery.dataTables.min.js"></script>
<script src="../datatable/js/jquery-1.12.0.min.js"></script>
<script src="../datatable/js/jquery.dataTables.min.js"></script>
<script src="../datatable/js/dataTables.buttons.min.js"></script>
<script src="../datatable/js/buttons.flash.min.js"></script>
<script src="../datatable/js/jszip.min.js"></script>
<script src="../datatable/js/pdfmake.min.js"></script>
<script src="../datatable/js/vfs_fonts.js"></script>
<script src="../datatable/js/buttons.html5.min.js"></script>
<script src="../datatable/js/buttons.print.min.js"></script>
<script>
$(document).ready(function() {
    $("#example").DataTable(
    {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
} );
</script>
    <!--- over datatable --->
    
