<?php include("header.php");?>


    <!--Breadcrumb start-->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js">
    </script>

    <div class="ed_pagetitle">
        <div class="ed_img_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="page_title">
                        <h2>services left sidebar</h2>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <ul class="breadcrumb">
                        <li><a href="index-2.html">home</a></li>
                        <li>//</li>
                        <li><a href="services_ls.html">services left sidebar</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--Breadcrumb end-->
    <!-- Services start -->

    <div class="ed_transprentbg ed_toppadder90 ed_bottompadder60">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-9 col-sm-9 col-lg-push-3 col-md-push-3 col-sm-push-3">
                    <div class="row">
                        <div class="ed_mostrecomeded_course_slider">
                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                <div class="ed_transprentbg ed_toppadder90 ed_bottompadder90">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="ed_heading_top ed_bottompadder50">
                                                    <h3>Login</h3>
                                                </div>
                                            </div>
                                            <form method="post">
                                                <div class="col-lg-6 col-md-6 col-sm-6">
                                                    <div class="ed_contact_form">

                                                        <div class="form-group">
                                                            <input type="text" id="email" class="form-control" name="email"  placeholder="Email">
                                                        </div>
                                                        <div class="form-group">
                                                            <input type="text" id="password" class="form-control" name="password"  placeholder="password">
                                                        </div>
                                                        <button id="login" class="btn ed_btn ed_orange pull-right">login</button>

                                                        <p id="err"></p>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>




                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>





                <!--Sidebar Start-->
                <div class="col-lg-3 col-md-3 col-sm-3 col-lg-pull-9 col-md-pull-9 col-sm-pull-9">
                    <div class="sidebar_wrapper">
                        <aside class="widget widget_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
								<button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
							</span>
                            </div>
                        </aside>


                        <aside class="widget widget_categories">
                            <h4 class="widget-title">Categories</h4>
                            <ul>
                                <li><a href="#">Dashboard</a></li>
                                <li><a href="#">Agent</a></li>
                                <li><a href="#">Carrier</a></li>
                                <li><a href="#">warehouse & distribution</a></li>
                            </ul>
                        </aside>
                    </div>

                </div>
                <!--Sidebar End-->
            </div>
        </div>
    </div>
    <!-- Services end -->
    <!-- Services end -->
    <!--Newsletter Section six start-->




    <script type="text/javascript">
        $(document).ready(function() {
            $("#login").click(function () {
                //debugger;
                  var email = $("#email").val();
                var password = $("#password").val();
                 $.ajax({
                    type: 'POST',
                    url: "http://192.168.200.163:8000/agent_login",
                     //contentType: "application/json",
                    data: {email:email,password:password},
                    success: function (data) {
                        if(data)
                        {
                            //console.log(data);
                            alert(JSON.stringify(data));
                           sessionStorage.setItem('user', JSON.stringify(data));
                       //   alert(sessionStorage.getItem('user')[0].agent_name);
                        //  console.log(sessionStorage.getItem('user'));
                         //   alert();

                            window.location="index.php";
                        }
                        else
                        {
                            alert("incorrect");
                        }

                    }

                });
                // show();
            });



        });

    </script>

    <!--Newsletter Section si')x end-->
<?php include("footer.php");?>