<?php include("header.php");?>
<!--Breadcrumb start-->
<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="page_title">
					<h2>services left sidebar</h2>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12">
				<ul class="breadcrumb">
					<li><a href="index-2.html">home</a></li>
					<li>//</li>
					<li><a href="services_ls.html">services left sidebar</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!-- Services start -->
<div class="ed_transprentbg ed_toppadder90 ed_bottompadder60">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-9 col-sm-9 col-lg-push-3 col-md-push-3 col-sm-push-3">
				<div class="row">
					<div class="ed_mostrecomeded_course_slider">
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ed_transprentbg ed_toppadder90 ed_bottompadder90">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="ed_heading_top ed_bottompadder50">
                                                <h3>Agent Information</h3>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6">
											<form action="" method="post">
						                        <div class="ed_contact_form">
													<input type="hidden" name="customer_id" id="customer_id">
	                                                <div class="form-group">
	                                                    <input type="text" name="customer_name" id="customer_name" class="form-control"  placeholder="Enter Name">
	                                                </div>
	                                                <div class="form-group">
	                                                    <input type="email" name="email" id="email" class="form-control"  placeholder="Enter Email">
	                                                </div>
	                                                <div class="form-group">
	                                                    <input type="text" name="password" id="password" class="form-control" rows="4" placeholder="Enter password">
	                                                </div>
	                                                <div class="form-group">
	                                                    <input type="text" name="contact" id="contact" class="form-control"  placeholder="Enter Contact">
	                                                </div>
	                                                <div class="form-group">
	                                                    <input type="text" name="address" id="address" class="form-control" rows="4" placeholder="Enter address">
	                                                </div>
	                                                <input type="submit" id="addclick" value="Add" class="btn ed_btn ed_orange pull-right">
	                                                <p id="err"></p>
                                            	</div>
											</form>
											<form id="form1">
											    <table class="table" border="1">
											        <thead>
											        <th>Customer Name</th>
											        <th>Email</th>
											        <th>Password</th>
											        <th>Contact</th>
											        <th>Address</th>
											        <th>Action</th>
											        </thead>
											        <tbody id="result-rows">
											        </tbody>
											    </table>
											</form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
					</div>
				</div>
			</div>
<!--Sidebar Start-->
			<div class="col-lg-3 col-md-3 col-sm-3 col-lg-pull-9 col-md-pull-9 col-sm-pull-9">
				<div class="sidebar_wrapper">
					<aside class="widget widget_search">
						<div class="input-group">
							<input type="text" class="form-control" placeholder="Search...">
							<span class="input-group-btn">
								<button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</aside>
					
					<aside class="widget widget_categories">
						<h4 class="widget-title">Categories</h4>
						<ul>
							<li><a href="#">taxi trucks</a></li>
							<li><a href="#">semi trailers</a></li>
							<li><a href="#">crane trucks</a></li>
							<li><a href="#">special projects</a></li>
							<li><a href="#">heavy haulage</a></li>
							<li><a href="#">wharf transport</a></li>
							<li><a href="#">freight forwarding</a></li>
							<li><a href="#">vehicle inspections</a></li>
							<li><a href="#">warehouse & distribution</a></li>
						</ul>
					</aside>
					
					<aside class="widget widget_archive">
						<h4 class="widget-title">Archives</h4>
						<ul>
							<li><a href="#">january 2018  (8)</a></li>
							<li><a href="#">february 2018  (6)</a></li>
							<li><a href="#">December 2016  (5)</a></li>
							<li><a href="#">October 2016  (3)</a></li>
							<li><a href="#">May 2016  (8)</a></li>
							<li><a href="#">August 2015  (7)</a></li>
						</ul>
					</aside>
					
					<aside class="widget widget_calendar">
						<h4 class="widget-title">calendar</h4>
						<div class="jquery-calendar"></div>
					</aside>
					
					<aside class="widget widget_tag_cloud">
						<h4 class="widget-title">Search by Tags</h4>
							<a href="#" class="ed_btn ed_orange">trucks</a>
							<a href="#" class="ed_btn ed_orange">crane</a>
							<a href="#" class="ed_btn ed_orange">freight</a>
							<a href="#" class="ed_btn ed_orange">distribution</a>
							<a href="#" class="ed_btn ed_orange">transport</a>
							<a href="#" class="ed_btn ed_orange">heavy</a>
							<a href="#" class="ed_btn ed_orange">warehouse</a>
					</aside>
				</div>
			</div>
<!--Sidebar End-->
		</div>
    </div>
</div>
<!-- Services end -->
<!--Newsletter Section six start-->
<div class="ed_newsletter_section ed_toppadder90 ed_bottompadder90">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="ed_newsletter_section_heading">
							<h4>Let us inform you about everything important directly.</h4>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-8 col-xs-12 col-lg-offset-3 col-md-offset-3 col-sm-offset-2 col-xs-offset-0">
						<div class="row">
							<div class="ed_newsletter_section_form">
								<form class="form">
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
										<input class="form-control" type="text" placeholder="Newsletter Email" />
									</div>
									<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
										<button class="btn ed_btn ed_green">confirm</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
	</div>
</div>
<!--Newsletter Section si')x end-->
<?php include("footer.php");?>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<link rel='stylesheet' type='text/css' href='https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css'>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script>

    function getallcustomers()
    {
        $.ajax({
            type: 'GET',
            //  dataType: "json",
            data: { },
            url: 'http://localhost:8000/getallcustomers',
            success: function (data) {
                var rows;
                $.each(data, function (i, item) {
                    //alert(item.name);
                    rows += "<tr>"
                        + "<td>" + item.customer_name + "</td>"
                        + "<td>" + item.email + "</td>"
                        + "<td>" + item.password + "</td>"
                        + "<td>" + item.contact + "</td>"
                        + "<td>" + item.address + "</td>"
                        + '<td><a href="javascript:void(0)" onclick="deleteRow(this,'+item.customer_id+')">Remove</a></td>'
                        + "</tr>";
                });
                $(".table tbody").append(rows);
            }
        });
    }

    $(document).ready(function() {
        getallcustomers();

        $(function(){
            $('#addclick').click(function(e){
                e.preventDefault();
                var data={};
                data.customer_name=document.getElementById('customer_name').value;
                data.email=document.getElementById('email').value;
                data.password=document.getElementById('password').value;
                data.contact=document.getElementById('contact').value;
                data.address=document.getElementById('address').value;

                $.ajax({
                    type: 'POST',
                    data: JSON.stringify(data),
                    contentType: 'application/json',
                    processData: false,
                    url: 'http://localhost:8000/customer_add',
                    success: function(data) {
                        clearAll();
                        getallcustomers();

                    }
                });

            });
        });

    });

    function clearAll() {
        document.getElementById("customer_id").value="";
        document.getElementById("customer_name").value="";
        document.getElementById("email").value="";
        document.getElementById("password").value="";
        document.getElementById("contact").value="";
        document.getElementById("address").value="";
        $("#result-rows").empty();

    }


    function deleteRow(obj, customer_id) {
       $.ajax({
            url: "http://localhost:8000/customer_delete/"+customer_id,
            type: "GET",
            data: { 'customer_id': customer_id },
            success: function(data){
                $(obj).closest('tr').fadeOut(300,function(){
                    $(obj).closest('tr').remove();
                });
            }
        });
    };
</script>

