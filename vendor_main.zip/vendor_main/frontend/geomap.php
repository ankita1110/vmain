<?php include("header.php");?>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true&key=AIzaSyBqWgpx8xS7aKBA_ADKoDdFfZm7N2_QtAA"></script>
<Style>
    .gmap{
        margin-left: 570px;
        margin-top: -95px;
    }
</Style>


<div class="ed_pagetitle">
    <div class="ed_img_overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="page_title">
                    <h2>services left sidebar</h2>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12">
                <ul class="breadcrumb">
                    <li><a href="index-2.html">home</a></li>
                    <li>//</li>
                    <li><a href="services_ls.html">services left sidebar</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!--Breadcrumb end-->
<!-- Services start -->

<div class="ed_transprentbg ed_toppadder90 ed_bottompadder60">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-9 col-lg-push-3 col-md-push-3 col-sm-push-3">
                <div class="row">
                    <div class="ed_mostrecomeded_course_slider">
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ed_transprentbg ed_toppadder90 ed_bottompadder90">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="ed_heading_top ed_bottompadder50">
                                                <h3>Login</h3>
                                            </div>
                                        </div>
                                        <form method="post">
                                            <div class="col-lg-6 col-md-6 col-sm-6">
                                                <div class="ed_contact_form">

                                                    <div class="form-group">
                                                        <input id="location-address" type="text" class="form-control" placeholder="Zipcode"/>

                                                    </div>
                                                    <button id="search" class="btn ed_btn ed_orange gmap">search</button>
                                                    <div id="map-canvas" style="height: 400px; width: 800px;">



                                                </div>
                                            </div>
                                        </form>
                                    </div>




                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>


</div>


            <!--Sidebar Start-->
            <div class="col-lg-3 col-md-3 col-sm-3 col-lg-pull-9 col-md-pull-9 col-sm-pull-9">
                <div class="sidebar_wrapper">
                    <aside class="widget widget_search">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
								<button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
							</span>
                        </div>
                    </aside>


                    <aside class="widget widget_categories">
                        <h4 class="widget-title">Categories</h4>
                        <ul>
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Agent</a></li>
                            <li><a href="#">Carrier</a></li>
                            <li><a href="#">warehouse & distribution</a></li>
                        </ul>
                    </aside>
                </div>

            </div>
            <!--Sidebar End-->
        </div>
    </div>
</div>
<!-- Services end -->
<!-- Services end -->
<!--Newsletter Section six start-->




<script>

    "use strict";
    var geocoder;
    var map;

    // setup initial map
    function initialize() {
        geocoder = new google.maps.Geocoder();
        var latlng = new google.maps.LatLng(40.6700, -73.9400);
        var mapOptions = {
            zoom: 8,
            center: latlng
        }
        map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
    }

    google.maps.event.addDomListener(window, 'load', initialize);
    $(document).ready(function() {
        // get map button functionality
        $("#search").click(function(event){
            event.preventDefault();
            var address = $("#location-address").val();
            $.ajax({
                type: 'POST',
                url: "http://192.168.200.163:8000/zip_search",
                data: {zipcode:address},
                success: function (data) {
                    if(data!=""){
                        var agent="";
                        for(var i=0;i<data.length;i++){
                            var zip=JSON.stringify(data[i]["zipcode"]);
                            agent+=(JSON.stringify(data[i]["agent_id"]) + ",");
                            geocoder.geocode( { 'address': zip}, function(results, status) {
                                if (status == google.maps.GeocoderStatus.OK) {
                                    map.setCenter(results[0].geometry.location);

                                    alert("loc");
                                    var marker = new google.maps.Marker({
                                        map: map,
                                        label: agent,
                                        position:results[0].geometry.location
                                    });
                                } else {
                                    alert('Geocode was not successful for the following reason: ' + status);
                                }
                            });
                        }

                    }
                    else
                    {
                        $('#map-canvas').html('Not found');
;                    }
                }

            });

        });
    });
</script>
<?php include("footer.php");?>



