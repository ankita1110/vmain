<!DOCTYPE html>
<!--    <script src="https://code.jquery.com/jquery-1.12.4.min.js">-->
<!--    </script>-->
<style>
    .t1class{
        text-align: right;
    }
</style>
<script>

    /*if(!sessionStorage['user'])
    {

        window.location="login.php";
    }*/

    // var agent=JSON.parse(sessionStorage.getItem('user'));
    // console.log(agent);
    // var agent_name=agent[0].agent_name;
    // if(agent=="null"){
    //     window.location="login.php";
    // }
    // //  var d="http://localhost:7000/"+user[0].image;
    // // alert(d);
    // //$('#agent_name').val("ghfg");
    // $('.t1class').html(agent_name);


    //document.getElementById('t1').innerHTML="sas";
    // document.getElementById('im').src=d;
</script>

<!--
Template Name: Transporting
Version: 1.0.0
Author: Kamleshyadav
Website: http://himanshusofttech.com/
Purchase: http://themeforest.net/user/kamleshyadav
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<!-- Begin Head -->

<!-- Mirrored from kamleshyadav.com/html/transport/transport/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Mar 2018 13:23:14 GMT -->
<head>
    <meta charset="utf-8" />
    <title>Transporting Multipurpose Responsive HTML Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta name="description"  content="Transporting"/>
    <meta name="keywords" content="Transporting, html template" />
    <meta name="author"  content="Kamleshyadav"/>
    <meta name="MobileOptimized" content="320" />

    <!--srart theme style -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <link href="css/main.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.js"></script>
    <!--    <script src="js/sweetalert.min.js"></script>-->

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- end theme style -->
    <!-- favicon links -->
    <link rel="shortcut icon" type="image/png" href="images/header/favicon.png" />


    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" />

    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

</head>
<body>
<!--Page main section start-->
<div id="pro_wrapper">
    <!--Header start-->
    <header id="ed_header_wrapper" class="header_transparent">
        <div class="ed_header_top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="pro_call">
                            <p>call now <i class="fa fa-volume-control-phone" aria-hidden="true"></i> 1800-2202-0909</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <!--                        <div class="ed_info_wrapper">-->
                        <!--                            <ul>-->
                        <!--                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>-->
                        <!--                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>-->
                        <!--                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>-->
                        <!--                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>-->
                        <!--                                <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>-->
                        <!--                            </ul>-->
                        <!--                        </div>-->
                        <div class="t1class"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ed_header_bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="pro_logo"> <a href="index-2.html"><img src="images/header/vend.png" alt="logo" /></a> </div>
                    </div>
                    <div class="col-lg-9 col-md-9 col-sm-9">
                        <div class="pro_menu_toggle navbar-toggle" data-toggle="collapse" data-target="#ed_menu">Menu <i class="fa fa-bars"></i>
                        </div>
                        <div class="pro_menu">
                            <ul class="collapse navbar-collapse" id="ed_menu">
                                <li><a href="index.php">Home</a>

                                </li>
                                <li><a href="about.php">about us</a></li>
                                <li><a href="first.php">Services</a>
                                </li>


                                <li><a href="contact.php">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>