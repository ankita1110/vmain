<?php include("header.php");?>
<style>
    .table{
        width: 70%;
    }
</style>

<!--Breadcrumb start-->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js">
    </script>

<div class="ed_pagetitle">
<div class="ed_img_overlay"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="page_title">
					<h2>services left sidebar</h2>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12">
				<ul class="breadcrumb">
					<li><a href="index-2.html">home</a></li>
					<li>//</li>
					<li><a href="services_ls.html">services left sidebar</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!--Breadcrumb end-->
<!-- Services start -->

<div class="ed_transprentbg ed_toppadder90 ed_bottompadder60">
		<div class="row">
			<div class="col-lg-9 col-md-9 col-sm-9 col-lg-push-3 col-md-push-3 col-sm-push-3">
				<div class="row">
					<div class="ed_mostrecomeded_course_slider">
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="ed_transprentbg ed_toppadder90 ed_bottompadder90">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="ed_heading_top ed_bottompadder50">
                                                <h3>Agent Information</h3>
                                            </div>
                                        </div>
                                        <form method="post">
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="ed_contact_form">
                                                <div class="form-group">
                                                    <input type="hidden" id="agent_id" class="form-control" name="agent_id" placeholder="Your Id">
                                                </div>

                                                <div class="form-group">
                                                    <input type="text" id="agent_name" class="form-control" name="agent_name"  placeholder="Your Name">
                                                </div>
                                                <div class="form-group">
                                                    <select name="state_id" id="state_id" class="form-control">
                                                        <option>---select---</option>
                                                    </select>
                                                </div>

                                                <div class="form-group">
                                                    <select name="city_id" id="city_id" class="form-control">
                                                        <option>---select---</option>
                                                    </select>
                                                </div>

                                                <div class="form-group">
                                                    <input type="text" id="street" class="form-control" name="street"  placeholder="Your Street">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="zipcode" class="form-control" name="zipcode"  placeholder="Zipcode">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="classification" class="form-control" name="classification"  placeholder="Classification">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="email" class="form-control" name="email"  placeholder="Email">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="password" class="form-control" name="password"  placeholder="password">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="landline" class="form-control" name="landline"  placeholder="Landline">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="cell" class="form-control" name="cell"  placeholder="Cell">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="company_name" class="form-control" name="company_name"  placeholder="Company name">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" id="notes_flag" class="form-control" name="notes_flag"  placeholder="Notes flag">
                                                </div>

                                                <button id="ed_submit" class="btn ed_btn ed_orange pull-right">send</button>
                                                <button id="update" class="btn ed_btn ed_orange pull-right">Update</button>
                                                <p id="err"></p>
                                            </div>
                                        </div>
                                        </form>
                                    </div>


                                    <table id="example" class="table table-responsive-lg" border="1">
                                        <thead>
                                        <th>Agent_id</th>
                                        <th>Agent_name</th>
                                        <th>City</th>
                                        <th>State</th>
                                        <th>Street</th>
                                        <th>Email</th>
                                        <th>Company Name</th>
                                        <th colspan="2">Action</th>

                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>

                                </div>
                            </div>

                        </div>

					</div>
				</div>
			</div>





    <!--Sidebar Start-->
			<div class="col-lg-3 col-md-3 col-sm-3 col-lg-pull-9 col-md-pull-9 col-sm-pull-9">
				<div class="sidebar_wrapper">
					<aside class="widget widget_search">
						<div class="input-group">
							<input type="text" class="form-control" placeholder="Search...">
							<span class="input-group-btn">
								<button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
							</span>
						</div>
					</aside>
					
					<aside class="widget widget_categories">
						<h4 class="widget-title">Categories</h4>
						<ul>
							<li><a href="#">Dashboard</a></li>
							<li><a href="#">Agent</a></li>
							<li><a href="#">Carrier</a></li>
							<li><a href="#">warehouse & distribution</a></li>
						</ul>
					</aside>

				</div>
			</div>
<!--Sidebar End-->
		</div>

</div>
<!-- Services end -->
<!-- Services end -->
<!--Newsletter Section six start-->




    <script type="text/javascript">
        $(document).ready(function() {
            $.ajax({
                type: 'GET',
                url: 'http://192.168.200.163:8000/agent_id',
                success: function (data) {
                    console.log(data);
                    var html;
                    $.each(data, function(i, item) {
                        html=item.agent_id;
                    });
                    var no=Number(html.substr(1));
                    no=no+1;
                    var id=no.toString();
                    var len=id.length;
                    console.log(len);
                    var cid="A";
                    for(i=0;i<5-len;i++)
                    {
                        cid+="0";
                    }
                    cid+=id;
                    console.log(cid);
                    //$( "#cid" ).value(cid);
                    document.getElementById('agent_id').value=cid;
                }
            });
            function state() {
                debugger;
                $.ajax({
                type: 'GET',
                    // contentType: "application/json",
                    url:"http://192.168.200.163:8000/states",
                    success:function (data) {
                   // console.log(data);
                        var p="";
                        for (var d in data){
                            if(data){
                                p+="<option value='"+data[d]["state_id"]+"'>";
                                p +=data[d]["state_name"];
                                p+="</option>";
                            }
                        }
                    $("#state_id").append(p);
                }
            })
            }

        state();

            $("#state_id").on('change',function () {
                var sid=$("#state_id").val();
                debugger;
                $.ajax({
                    type: 'GET',
                    // contentType: "application/json",
                    url:"http://192.168.200.163:8000/city/"+sid,
                    success:function (data) {
                        // console.log(data);
                        var p="";
                        for (var d in data){
                            if(data){
                                p+="<option value='"+data[d]["city_id"]+"'>";
                                p +=data[d]["city_name"];
                                p+="</option>";
                            }
                        }
                        $("#city_id").html(p);
                    }
                })
                
            })

        function show () {

            //debugger;
                $.ajax({
                    type: 'GET',
                   // contentType: "application/json",
                    url: "http://192.168.200.163:8000/show",

                    success: function (data) {
                        //alert(JSON.stringify(data));
                        var p = "";
                        for (var d in data) {
                            //console.log(data[d]["image"]);
                            if (data) {
                                p += "<tr>";
                                p += "<td>" + data[d]["agent_id"] + "</td>";
                                p += "<td>" + data[d]["agent_name"] + "</td>";
                                p += "<td>" + data[d]["city_name"] + "</td>";
                                p += "<td>" + data[d]["state_name"] + "</td>";
                                p += "<td>" + data[d]["street"] + "</td>";
                                p += "<td>" + data[d]["email"] + "</td>";
                                p += "<td>" + data[d]["company_name"] + "</td>";
                                p += "<td><i class='fa fa-trash fa-2x de' style='color:red' data-toggle='modal' id="+data[d]['agent_id']+" value="+data[d]['agent_id']+" data-target='' onclick=del('"+data[d]['agent_id']+"')></i></td>";
                                p += "<td><i class='fa fa-pencil-square fa-2x dis' style='color:green'  id=" + data[d]['agent_id'] + "   name=" + data[d]['agent_name'] + "></i></td>";
                                p += "</tr>";
                            }
                         //   var d1 = data[d]["id"];
                        }
                        $("#example tbody").html(p);
                    }
                }).done(function () {



                    $(".dis").click(function () {

                        var a=$(this).attr("name");
                        var agent_id=$(this).attr("id");

                        // var name = $("#name").val(a);
                        $.ajax({

                            type: 'GET',
                            // contentType: "application/json",
                            url: "http://192.168.200.163:8000/sel?agent_id="+agent_id,
                            success: function (data) {
                                $('#agent_id').val(data[0].agent_id);
                                $('#agent_name').val(data[0].agent_name);
                                $('#city_id').val(data[0].city_id);
                                $('#state_id').val(data[0].state_id);
                                $('#street').val(data[0].street);
                                $('#zipcode').val(data[0].zipcode);
                                $('#classification').val(data[0].classification);
                                $('#email').val(data[0].email);
                                $('#landline').val(data[0].landline);
                                $('#cell').val(data[0].cell);
                                $('#company_name').val(data[0].company_name);
                            }
                        });
                        // alert(id);



                        // alert(name.toString());
                    });

                })
            $("#update").click(function () {
                alert();
                var agent_id=$("#agent_id").val();
                alert(agent_id);
                var agent_name= $("#agent_name").val();
                var city_id = $("#city_id").val();
                var state_id = $("#state_id").val();
                var street = $("#street").val();
                var zipcode = $("#zipcode").val();
                var classification = $("#classification").val();
                var email = $("#email").val();
                var password = $("#password").val();
                var landline = $("#landline").val();
                var cell = $("#cell").val();
                var company_name = $("#company_name").val();
                $.ajax({

                    type: 'POST',
                    // contentType: "application/json",
                    url: "http://192.168.200.163:8000/update/?agent_id="+agent_id,
                    data: {agent_id:agent_id,agent_name:agent_name,city_id:city_id,state_id:state_id,street:street,zipcode:zipcode,classification:classification,email:email,landline:landline,cell:cell,company_name:company_name},
                    success: function (data) {
                        show();

                    }
                });
            });
        }
        show();




            $("#ed_submit").click(function () {
              //  e.preventDefault();
            // alert();
                 debugger;
            var agent_id = $("#agent_id").val();
            var agent_name= $("#agent_name").val();
            var city_id = $("#city_id").val();
            var state_id = $("#state_id").val();
            var street = $("#street").val();
            var zipcode = $("#zipcode").val();
            var classification = $("#classification").val();
                var email = $("#email").val();
                var password = $("#password").val();
                var landline = $("#landline").val();
                var cell = $("#cell").val();
                var company_name = $("#company_name").val();
                var notes_flag = $("#notes_flag").val();
        alert(agent_name);
            $.ajax({
                type: 'POST',
                url: "http://192.168.200.163:8000/register",
                data: {agent_id:agent_id,agent_name:agent_name,city_id:city_id,state_id:state_id,street:street,zipcode:zipcode,classification:classification,email:email,password:password,landline:landline,cell:cell,company_name:company_name,notes_flag:notes_flag},
                success: function (data) {
                   show();
                }

            });
           // show();
        });



        });
        function del(z) {
            var id = z;
            console.log(id);

            bootbox.confirm({
                message: " Do you want to delete it?",
                buttons: {
                    confirm: {
                        label: 'Yes',
                        className: 'btn-success'
                    },
                    cancel: {
                        label: 'No',
                        className: 'btn-danger'
                    }
                },
                callback: function (result) {
                    var a=result;
                    console.log(a);
                    if(a)
                    {

                        $.ajax({
                            type:'GET',
                                url:'http://192.168.200.163:8000/del?agent_id='+id,
                            success:function(data)
                            {
                                window.location.reload(true);
                            }
                        });

                    }

                }
            });
        }

        </script>

        <!--Newsletter Section si')x end-->
<?php include("footer.php");?>