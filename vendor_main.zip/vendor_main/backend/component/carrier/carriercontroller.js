let con=require('../../config/db');

exports.states=(req,res)=>{

    con.query('select * from state',(err,result,fields)=>{
        if(err){
            console.log(err);
            res.send('error in selecting');
        }
        //console.log(result);
        return res.status(200).send(result);
    });
};
exports.city=(req,res)=>{
    var sid=req.params.id;
    console.log(sid);

    console.log("select * from city where state_id="+sid);
    con.query("select * from city where state_id="+sid,(err,result,feilds)=>{
        if(err){
            res.send('error in query');
        }
        console.log(result);
        return res.status(200).send(result);
    });
};
exports.carrier_insert=(req,res)=>{
    var cid=req.body.cid;
    var cnm=req.body.cname;
    var cstreet=req.body.cstreet;
    var cstate=req.body.cstate;
    var ccity=req.body.ccity;
    var czip=req.body.czip;
    var cclas=req.body.cclassification;
    var cemail=req.body.cemail;
    var cmob=req.body.cmob;
    var cland=req.body.clandline;
    var company=req.body.ccompanyname;
    var pwd=req.body.cpassword;
    var status=req.body.cstatus;
    console.log('in');
    con.query("INSERT INTO carrier (carrier_id, carrier_name, city_id, state_id, street, zipcode, classification, email, password, landline, cell, company_name, status) VALUES ('"+cid+"','"+cnm+"','"+ccity+"','"+cstate+"','"+cstreet+"','"+czip+"','"+cclas+"','"+cemail+"','"+pwd+"','"+cland+"','"+cmob+"','"+company+"','"+status+"')",(err,result,feilds)=>{
        if(err){
            res.send('error in query');
        }
        console.log(result);
        return res.status(200).send(result);
    });
};
exports.carrier_view=(req,res)=>{
    con.query("select carrier_id, carrier_name, street, zipcode, classification, email, password, landline, cell, company_name, status, city_name, state_name from carrier c,state s,city ct where c.state_id=s.state_id and c.city_id=ct.city_id",(err,result,feilds)=>{
        if(err){
            return res.send('error in selecting')
        }
        //console.log(result);
        return res.send(result);
    });
};
exports.carrier_id=(req,res)=>{
    con.query("SELECT * FROM `carrier` ORDER BY `carrier_id` DESC LIMIT 1",(err,result,feilds)=>{
        if(err){
            console.log(err);
            return res.send('error in selecting');
        }
        console.log(result);
        return res.send(result);
    });
};
exports.carrier_update_data=(req,res)=>{
    var cid=req.params.id;
    console.log(cid);
    //console.log("select * from carrier where carrier_id="+cid);
    con.query("select * from carrier where carrier_id='"+cid+"'",(err,result,feilds)=>{
        if(err){
            console.log(err);
            return res.send('error in selecting');
        }
        console.log(result);
        return res.send(result);
    });
};
exports.carrier_update=(req,res)=>{
    var cid=req.body.cid;
    var cnm=req.body.cname;
    var cstreet=req.body.cstreet;
    var cstate=req.body.cstate;
    var ccity=req.body.ccity;
    var czip=req.body.czip;
    var cclas=req.body.cclassification;
    var cemail=req.body.cemail;
    var cmob=req.body.cmob;
    var cland=req.body.clandline;
    var company=req.body.ccompanyname;
    var pwd=req.body.cpassword;
    var status=req.body.cstatus;
    console.log('in');
    con.query("UPDATE carrier SET carrier_name='"+cnm+"',city_id='"+ccity+"',state_id='"+cstate+"',street='"+cstreet+"',zipcode='"+czip+"',classification='"+cclas+"',email='"+cemail+"',password='"+pwd+"',landline='"+cland+"',cell='"+cmob+"',company_name='"+company+"',status='"+status+"' WHERE carrier_id='"+cid+"'",(err,result,feilds)=>{
        if(err){
            console.log(err)
            return res.send('error in query');
        }
        console.log(result);
        return res.status(200).send(result);
    });
};
