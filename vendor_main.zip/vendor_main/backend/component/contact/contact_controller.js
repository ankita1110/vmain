let con=require('../../config/db');

exports.fetch_contact=(req,res)=>{
console.log("fff");
    con.query("select * from contact where delete_flag=0",function (err,rows) {
        if(err)  throw  err;
        res.send(rows);
    });
};

exports.fetch_contact_byid= (req,res)=>{
    var id=req.params.id;

    con.query('SELECT * FROM contact where contact_id='+id,function (err,rows) {
        if(err)  throw  err;
        res.send(rows);
    });
};

exports.contact_insert=(req,res)=>{
    console.log('insert request call');
    var data = req.body;

    var a='insert into contact set ?';
    con.query(a,data,function(err, rows)
    {
        if (err) throw err;
        else{
            console.log("insert successfully...");
            // res.send({_id:rows.insertId});
            res.send("insert");
        }
    });
};

exports.contact_edit=(req,res)=> {
    var id = req.params.id;

    con.query("update contact set fname='"+req.body.fname+"',lname='"+req.body.lname+"',phno='"+req.body.phno+"',email='"+req.body.email+"',contact_type='"+req.body.contact_type+"',message='"+req.body.message+"' where contact_id="+id,function(err,rows)
    {
        if (err){
            res.status(500).send({"data":"error"});
        }
        else{
            res.status(200).send({"data":"success"});
        }
    });
};

exports.delete_contact=(req,res)=>{
    var id=req.params.id;
    console.log('delete request call');
    con.query('update contact set delete_flag=1 where contact_id='+id, function(err, rows, fields)
    {
        if (err) throw err;
        else{
            res.send({"data":"success"});
        }
    });
};