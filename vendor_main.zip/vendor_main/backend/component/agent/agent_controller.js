let con=require('../../config/db');

exports.states=(req,res)=>{

    con.query('select * from state',(err,result,fields)=>{
        if(err){
            console.log(err);
            res.send('error in selecting');
        }
        //console.log(result);
        return res.status(200).send(result);
    });
};
exports.city=(req,res)=>{
    var sid=req.params.id;
    console.log(sid);

    console.log("select * from city where state_id="+sid);
    con.query("select * from city where state_id="+sid,(err,result,feilds)=>{
        if(err){
            res.send('error in query');
        }
        console.log(result);
        return res.status(200).send(result);
    });
};

exports.register=(req,res)=>{
    console.log("");
    var agent_id=req.body.agent_id;
    var agent_name=req.body.agent_name;
    var city_id=req.body.city_id;
    var state_id=req.body.state_id;
    var street=req.body.street;
    var zipcode=req.body.zipcode;
    var classification=req.body.classification;
    var email=req.body.email;
    var password=req.body.password;
    var landline=req.body.landline;
    var cell=req.body.cell;
    var company_name=req.body.company_name;
    var notes_flag=req.body.notes_flag;
    var status=req.body.status;
    var agent_query="insert into agent (agent_id,agent_name,city_id,state_id,street,zipcode,classification,email,password,landline,cell,company_name,notes_flag,status)values('"+agent_id+"','"+agent_name+"',"+city_id+","+state_id+",'"+street+"',"+zipcode+",'"+classification+"','"+email+"','"+password+"',"+landline+","+cell+",'"+company_name+"','"+notes_flag+"',1)";
    console.log(agent_query);
    con.query(agent_query,(err,row)=>{
        console.log("inserting");
        res.send("inserting");
    })
};

exports.show=(req,res)=>{
    console.log("show");
    con.query("SELECT c.city_id,c.city_name,s.state_id,s.state_name,a.* FROM agent as a,city as c,state as s where a.state_id=s.state_id and c.city_id=a.city_id and status=1", function (err, result, fields) {
        if (err) throw err;
        res.send(result);

    })


};

exports.del=(req,res)=>{
    var agent_id=req.query.agent_id;
    var qry="update agent set status=0 where agent_id='"+agent_id+"'";
    con.query(qry,(err, result)=>{
        if (err) throw err;
        res.send('deleted');

    })
};

exports.update=(req,res)=>{
    var agent_id=req.query.agent_id;
    var agent_name=req.body.agent_name;
    var city_id=req.body.city_id;
    var state_id=req.body.state_id;
    var street=req.body.street;
    var zipcode=req.body.zipcode;
    var classification=req.body.classification;
    var email=req.body.email;
    var password=req.body.password;
    var landline=req.body.landline;
    var cell=req.body.cell;
    var company_name=req.body.company_name;
    var notes_flag=req.body.notes_flag;
    var status=req.body.status;
    var que="update agent set agent_name='"+agent_name+"',city_id='"+city_id+"',state_id='"+state_id+"',street='"+street+"',zipcode="+zipcode+",classification='"+classification+"',email='"+email+"',landline="+landline+",cell="+cell+",company_name='"+company_name+"',notes_flag='"+notes_flag+"' where agent_id='"+agent_id+"'";
    console.log(que);
    con.query(que,function (err,result) {
        if(err)throw err;
        res.send(result);
    })
};

exports.sel=(req,res)=>{
    var agent_id=req.query.agent_id;
    var qu="select * from agent where agent_id='"+agent_id+"'";
    console.log(qu);
    con.query(qu,function (err,result) {
        res.send(result);

    })
};

exports.states=(req,res)=>{
    con.query('select * from state',(err,result,fields)=>{
        if(err){
            console.log(err);
            res.send('error in selecting');
        }
        console.log(result);
        res.send(result);
    });
};


exports.city=(req,res)=>{
    var sid=req.params.id;
    console.log(sid);
    con.query("select * from city where state_id="+sid,(err,result,fields)=>{
        if(err){
            res.send('error in query');
        }
        console.log(result);
        res.send(result);
    });
};

exports.agent_login=(req,res)=>{
    var email=req.body.email;
    var password=req.body.password;
    var a_login="select * from agent where email='"+email+"' and password='"+password+"'";
    console.log(a_login);
    con.query(a_login,(err,result)=>{
        if(err){
            res.send("error");
        }
        console.log(result);
        if(result=="")
        {
            res.send("error");
        }
        else
        {
            res.send("success");
        }

    })
};

exports.agent_id=(req,res)=>{
    con.query("SELECT * FROM agent ORDER BY agent_id DESC LIMIT 1",(err,result)=>{
        if(err){
            console.log(err);
            return res.send('error in selecting');
        }
        console.log(result);
        return res.send(result);
    });
};


