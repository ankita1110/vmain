let carrier=require('../component/carrier/carriercontroller');
let agent=require('../component/agent/agent_controller');
let contact=require('../component/contact/contact_controller');

exports.route=(app)=>{
    //carrier management
    app.get('/states',carrier.states);
    app.get('/city/:id',carrier.city);
    app.post('/carrier_insert',carrier.carrier_insert);
    app.get('/carrier_view',carrier.carrier_view);
    app.get('/carrier_id',carrier.carrier_id);
    app.get('/carrier_update_data/:id',carrier.carrier_update_data);
    app.post('/carrier_update',carrier.carrier_update);


    //agent management
    app.post('/register',agent.register);
    app.get('/states',agent.states);
    app.get('/city/:id',agent.city);
    app.get('/show',agent.show);
    app.post('/update',agent.update);
    app.get('/del',agent.del);
    app.get('/sel',agent.sel);
    app.get('/agent_id',agent.agent_id);
    app.post('/agent_login',agent.agent_login);

    //contact management
    app.get('/fetch_contact',contact.fetch_contact);
    app.get('/fetch_contact_byid/:id',contact.fetch_contact_byid);
    app.post('/contact_insert',contact.contact_insert);
    app.post('/contact_edit/:id',contact.contact_edit);
    app.delete('/delete_contact/:id',contact.delete_contact);

};