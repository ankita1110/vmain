const mysql=require('mysql');
var con=mysql.createConnection({
    host:"192.168.200.163",
    user:"test",
    password:"test",
    database:"vendordb"
});
con.connect((err)=>{
    if(err){
        console.log(err);
        res.send('connection error');
    }
});
module.exports=con;