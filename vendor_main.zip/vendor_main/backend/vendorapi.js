const express=require('express');
const bodyParser=require('body-parser');
const cors=require('cors');
const router=require('./routes/index');

var app=express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));
app.use(cors());



router.route(app);
app.listen(8000,()=>{
    console.log('Port 8000');
})